﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AdminLogin.aspx.cs" Inherits="EventManagementSystem.AdminLogin" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="text-align:center; margin-top:100px;">
            <h2>Admin Login</h2><br />

            Admin Username:<br />
            <asp:TextBox ID="txtAdminUsername" runat="server"></asp:TextBox><br /><br />
            Password:<br />
            <asp:TextBox ID="txtAdminPassword" runat="server" TextMode="Password"></asp:TextBox><br /><br />

            <asp:Button ID="btnAdminLogin" runat="server" Text="Login" OnClick="btnAdminLogin_Click" /><br /><br />

            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br />

            <br /><a href="Home.aspx">Back to Home</a>
        </div>
    </form>
</body>
</html>
