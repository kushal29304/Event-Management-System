﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="EventManagementSystem.Home" %>

<!DOCTYPE html>
<html>
<head>
    <title>Home - Event Management System</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="text-align: center; margin-top: 50px;">
            <h1>Welcome to Event Management System</h1>
            <br />
            <br />

            <asp:Button ID="btnViewEvents" runat="server" Text="View Available Events" OnClick="btnViewEvents_Click" /><br />
            <br />
           <%-- <asp:Button ID="btnRegisterEvent" runat="server" Text="Register for Event" OnClick="btnRegisterEvent_Click" /><br />--%>
           <%-- <br />--%>
            <%--<asp:Button ID="btnMyRegistrations" runat="server" Text="My Registrations" OnClick="btnMyRegistrations_Click" /><br />
            <br />
            <asp:Button ID="btnUserLogin" runat="server" Text="User Login" OnClick="btnUserLogin_Click" /><br />
            <br />
            <asp:Button ID="btnAdminLogin" runat="server" Text="Admin Login" OnClick="btnAdminLogin_Click" /><br />
            <br />

        </div>
    </form>
</body>
</html>--%>
<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Home.aspx.cs" Inherits="EventManagementSystem.Home" %>

<!DOCTYPE html>
<html>
<head>
    <title>Home - Event Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            text-align: center;
            margin-top: 100px;
        }

        h1 {
            color: #333;
        }

        .btn {
            padding: 12px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin: 10px 0;
            width: 250px;
            border-radius: 5px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-container {
            margin-top: 50px;
        }

        .btn-container a {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h1>Welcome to Event Management System</h1>

            <div class="btn-container">
                <asp:Button ID="btnViewEvents" runat="server" Text="View Available Events" OnClick="btnViewEvents_Click" CssClass="btn" /><br />
                
                <!-- Uncomment and add more functionality as needed -->
                <!-- <asp:Button ID="btnRegisterEvent" runat="server" Text="Register for Event" OnClick="btnRegisterEvent_Click" CssClass="btn" /><br /> -->
                
                <!-- <asp:Button ID="btnMyRegistrations" runat="server" Text="My Registrations" OnClick="btnMyRegistrations_Click" CssClass="btn" /><br /> -->
                <asp:Button ID="btnUserRegister" runat="server" Text="User Register" OnClick="btnUserRegister_Click" CssClass="btn" /><br />
                <asp:Button ID="btnUserLogin" runat="server" Text="User Login" OnClick="btnUserLogin_Click" CssClass="btn" /><br />
                <asp:Button ID="btnAdminLogin" runat="server" Text="Admin Login" OnClick="btnAdminLogin_Click" CssClass="btn" /><br />
            </div>
        </div>
    </form>
</body>
</html>

