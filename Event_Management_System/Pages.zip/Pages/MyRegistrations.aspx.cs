﻿//using System;
//using System.Data.SqlClient;
//using System.Data;

//namespace EventManagementSystem
//{
//    public partial class MyRegistrations : System.Web.UI.Page
//    {
//        protected void btnView_Click(object sender, EventArgs e)
//        {
//            string username = txtUsername.Text.Trim();

//            // Get UserID first
//            string getUserQuery = "SELECT UserID FROM event_management.Users WHERE Username = @Username";
//            SqlParameter[] userParam = { new SqlParameter("@Username", username) };

//            int userId = -1;
//            using (SqlDataReader reader = Database.GetDataReader(getUserQuery, userParam))
//            {
//                if (reader.Read())
//                {
//                    userId = Convert.ToInt32(reader["UserID"]);
//                }
//                else
//                {
//                    lblMessage.Text = "User not found!";
//                    gvRegistrations.DataSource = null;
//                    gvRegistrations.DataBind();
//                    return;
//                }
//            }

//            // Get user's registrations
//            string registrationsQuery = @"
//                SELECT e.EventName, e.EventDate, e.Venue 
//                FROM event_management.Events e
//                INNER JOIN event_management.EventRegistrations r ON e.EventID = r.EventID
//                WHERE r.UserID = @UserID";

//            SqlParameter[] regParams = { new SqlParameter("@UserID", userId) };

//            using (SqlDataReader reader = Database.GetDataReader(registrationsQuery, regParams))
//            {
//                DataTable dt = new DataTable();
//                dt.Load(reader);

//                if (dt.Rows.Count > 0)
//                {
//                    gvRegistrations.DataSource = dt;
//                    gvRegistrations.DataBind();
//                    lblMessage.Text = "";
//                }
//                else
//                {
//                    lblMessage.Text = "No registrations found!";
//                    gvRegistrations.DataSource = null;
//                    gvRegistrations.DataBind();
//                }
//            }
//        }

//        private class Database
//        {
//            internal static SqlDataReader GetDataReader(string getUserQuery, SqlParameter[] userParam)
//            {
//                throw new NotImplementedException();
//            }
//        }
//    }
//}
using System;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class MyRegistrations : System.Web.UI.Page
    {
        protected void btnView_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            if (string.IsNullOrWhiteSpace(username))
            {
                lblMessage.Text = "Please enter your username.";
                ClearGrid();
                return;
            }

            // 1) Lookup UserID
            const string getUserSql = @"
                SELECT UserID 
                  FROM Users 
                 WHERE Username = @Username";
            var userParam = new MySqlParameter("@Username", username);

            int userId;
            using (var reader = Database.GetDataReader(getUserSql, new[] { userParam }))
            {
                if (!reader.Read())
                {
                    lblMessage.Text = "User not found!";
                    ClearGrid();
                    return;
                }
                userId = reader.GetInt32(reader.GetOrdinal("UserID"));
            }

            // 2) Fetch their registrations
            const string regsSql = @"
                SELECT e.EventName, e.EventDate, e.Venue
                  FROM Events e
                  JOIN EventRegistrations r 
                    ON e.EventID = r.EventID
                 WHERE r.UserID = @UserID
                 ORDER BY e.EventDate";
            var regParam = new MySqlParameter("@UserID", userId);

            using (var reader = Database.GetDataReader(regsSql, new[] { regParam }))
            {
                var dt = new DataTable();
                dt.Load(reader);

                if (dt.Rows.Count > 0)
                {
                    gvRegistrations.DataSource = dt;
                    gvRegistrations.DataBind();
                    lblMessage.Text = "";
                }
                else
                {
                    lblMessage.Text = "No registrations found!";
                    ClearGrid();
                }
            }
        }

        private void ClearGrid()
        {
            gvRegistrations.DataSource = null;
            gvRegistrations.DataBind();
        }
    }
}
