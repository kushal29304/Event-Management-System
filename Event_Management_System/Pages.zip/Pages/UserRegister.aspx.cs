﻿using System;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class UserRegister : System.Web.UI.Page
    {
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Trim inputs
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string fullName = txtFullName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string phone = txtPhone.Text.Trim();

            // 1) Required fields check
            if (string.IsNullOrWhiteSpace(username)
                || string.IsNullOrWhiteSpace(password)
                || string.IsNullOrWhiteSpace(fullName)
                || string.IsNullOrWhiteSpace(email)
                || string.IsNullOrWhiteSpace(phone))
            {
                ShowMessage("All fields are required.", isError: true);
                return;
            }

            // 2) Phone validation: exactly 10 digits
            if (!System.Text.RegularExpressions.Regex.IsMatch(phone, @"^\d{10}$"))
            {
                ShowMessage("Phone number must be exactly 10 digits.", isError: true);
                return;
            }

            // 3) Email validation
            if (!System.Text.RegularExpressions.Regex.IsMatch(
                    email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                ShowMessage("Enter a valid email address.", isError: true);
                return;
            }

            // 4) Password strength: ≥8 chars, uppercase, lowercase, digit, special char
            if (!System.Text.RegularExpressions.Regex.IsMatch(
                    password,
                    @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"))
            {
                ShowMessage(
                    "Password must be at least 8 characters and include uppercase, lowercase, digit, and special character.",
                    isError: true);
                return;
            }

            // 5) Username uniqueness check
            const string checkSql = "SELECT COUNT(1) FROM Users WHERE Username=@Username";
            var checkParams = new[]
            {
        new MySqlParameter("@Username", username)
    };
            int exists = Convert.ToInt32(Database.ExecuteScalar(checkSql, checkParams));
            if (exists > 0)
            {
                ShowMessage("Username already exists. Please choose another.", isError: true);
                return;
            }

            // 6) All validations passed—insert user
            const string insertSql = @"
        INSERT INTO Users
            (Username, Password, FullName, Email, Phone)
        VALUES
            (@Username, @Password, @FullName, @Email, @Phone)";
            var insertParams = new[]
            {
        new MySqlParameter("@Username", username),
        new MySqlParameter("@Password", password),
        new MySqlParameter("@FullName",  fullName),
        new MySqlParameter("@Email",     email),
        new MySqlParameter("@Phone",     phone)
    };
            Database.ExecuteNonQuery(insertSql, insertParams);

            ShowMessage("Registration successful! Please log in.", isError: false);
            ClearForm();
        }

        // Helper to show messages
        private void ShowMessage(string text, bool isError)
        {
            lblMessage.Text = text;
            lblMessage.CssClass = isError ? "msg-error" : "msg-success";
        }

        // Clears form inputs
        private void ClearForm()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtFullName.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
        }


        //private void ShowMessage(string text, bool isError)
        //{
        //    lblMessage.Text = text;
        //    lblMessage.CssClass = isError ? "msg-error" : "msg-success";
        //}

        //private void ClearForm()
        //{
        //    txtUsername.Text = "";
        //    txtPassword.Text = "";
        //    txtFullName.Text = "";
        //    txtEmail.Text = "";
        //    txtPhone.Text = "";
        //}

        // Simple regex email validation
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            var pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }
    }
}
