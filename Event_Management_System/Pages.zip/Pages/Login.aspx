﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="EventManagementSystem.Login" %>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="text-align: center; margin-top: 100px;">
            <h2>Login</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br />
            <label for="txtUsername">Username:</label><br />
            <asp:TextBox ID="txtUsername" runat="server"></asp:TextBox><br /><br />
            <label for="txtPassword">Password:</label><br />
            <asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox><br /><br />
            <asp:Button ID="btnLogin" runat="server" Text="Login" OnClick="btnLogin_Click" />
        </div>
    </form>
</body>
</html>--%>
<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="EventManagementSystem.Login" %>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        .form-container {
            text-align: center;
            margin-top: 100px;
            font-family: Arial, sans-serif;
        }

        .form-container input {
            margin-bottom: 10px;
            padding: 8px;
            width: 200px;
        }

        .form-container label {
            font-size: 16px;
            font-weight: bold;
        }

        .form-container .btn {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            margin: 10px 5px;
        }

        .form-container .btn:hover {
            background-color: #45a049;
        }

        .form-container .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="form-container">
            <h2>Login</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red" CssClass="error-message"></asp:Label><br />
            
            <label for="txtUsername">Username:</label><br />
            <asp:TextBox ID="txtUsername" runat="server" CssClass="input-field"></asp:TextBox><br /><br />
            
            <label for="txtPassword">Password:</label><br />
            <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" CssClass="input-field"></asp:TextBox><br /><br />
            
            <asp:Button ID="btnLogin" runat="server" Text="Login" OnClick="btnLogin_Click" CssClass="btn" />
            <br />
            
            <!-- Registration Button -->
            <asp:Button ID="btnRegister" runat="server" Text="Register" OnClick="btnRegister_Click" CssClass="btn" />
        </div>
    </form>
</body>
</html>
