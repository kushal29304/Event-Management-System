﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="UserLogin.aspx.cs" Inherits="EventManagementSystem.UserLogin" %>

<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="text-align:center; margin-top:100px;">
            <h2>User Login</h2><br />

            Username:<br />
            <asp:TextBox ID="txtUsername" runat="server"></asp:TextBox><br /><br />

            <asp:Button ID="btnLogin" runat="server" Text="Login" OnClick="btnLogin_Click" /><br /><br />

            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br />

            <br /><a href="Home.aspx">Back to Home</a>
        </div>
    </form>
</body>
</html>--%>
<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="UserRegister.aspx.cs" Inherits="EventManagementSystem.UserRegister" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>User Registration</title>
    <style>
        .form-container {
            width: 320px;
            margin: 100px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        .form-container h2 {
            text-align: center;
        }
        .form-container .input-row {
            margin-bottom: 12px;
        }
        .form-container .input-row label {
            display: block;
            margin-bottom: 4px;
        }
        .form-container .input-row input {
            width: 100%;
            padding: 6px;
            box-sizing: border-box;
        }
        .form-container .btn-submit {
            width: 100%;
            padding: 8px;
            background: #007bdb;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .msg-success { color: green; }
        .msg-error   { color: red;   }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="form-container">
            <h2>User Registration</h2>

            <asp:Label ID="lblMessage" runat="server" CssClass="msg-error" Text="" />

            <div class="input-row">
                <label for="txtUsername">Username</label>
                <asp:TextBox ID="txtUsername" runat="server" />
            </div>

            <div class="input-row">
                <label for="txtPassword">Password</label>
                <asp:TextBox ID="txtPassword" runat="server" TextMode="Password" />
            </div>

            <div class="input-row">
                <label for="txtFullName">Full Name</label>
                <asp:TextBox ID="txtFullName" runat="server" />
            </div>

            <div class="input-row">
                <label for="txtEmail">Email</label>
                <asp:TextBox ID="txtEmail" runat="server" TextMode="Email" />
            </div>

            <div class="input-row">
                <label for="txtPhone">Phone</label>
                <asp:TextBox ID="txtPhone" runat="server" />
            </div>

            <asp:Button ID="btnRegister" runat="server" CssClass="btn-submit"
                        Text="Register" OnClick="btnRegister_Click" />

            <div style="text-align:center; margin-top:8px;">
                <a href="Login.aspx">Back to Login</a>
            </div>
        </div>
    </form>
</body>
</html>
