﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="MyRegistrations.aspx.cs" Inherits="EventManagementSystem.MyRegistrations" %>

<!DOCTYPE html>
<html>
<head>
    <title>My Event Registrations</title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <h2>My Registrations</h2>

            <label for="txtUsername">Enter Username:</label>
            <asp:TextBox ID="txtUsername" runat="server"></asp:TextBox>
            <asp:Button ID="btnView" runat="server" Text="View Registrations" OnClick="btnView_Click" /><br /><br />

            <asp:Label ID="lblMessage" runat="server" ForeColor="Red"></asp:Label><br />

            <asp:GridView ID="gvRegistrations" runat="server" AutoGenerateColumns="True"></asp:GridView>
        </div>
    </form>
</body>
</html>
