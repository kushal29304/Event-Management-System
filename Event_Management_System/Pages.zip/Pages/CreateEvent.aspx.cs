﻿//using System;
//using System.Data.SqlClient;
//using System.Web.UI.WebControls;
//using MySql.Data.MySqlClient;

//namespace EventManagementSystem
//{
//    public partial class CreateEvent : System.Web.UI.Page
//    {
//        protected void btnCreateEvent_Click(object sender, EventArgs e)
//        {
//            // Ensure validation
//            if (Page.IsValid)
//            {

//                string eventName = txtEventName.Text;
//                string description = txtDescription.Text;
//                string eventDate = txtEventDate.Text;
//                string venue = txtVenue.Text;
//
//              

//                // Insert event data into database (use your database method here)
//                string query = "INSERT INTO Events (EventName, Description, EventDate, Venue, TotalSeats) VALUES (@EventName, @Description, @EventDate, @Venue, @TotalSeats)";
//                MySqlParameter[] parameters = {
//            new MySqlParameter("@EventName", eventName),
//            new MySqlParameter("@Description", description),
//            new MySqlParameter("@EventDate", DateTime.Parse(eventDate)),
//            new MySqlParameter("@Venue", venue),
//            new MySqlParameter("@TotalSeats", totalSeats)
//        };
//                Database.ExecuteQuery(query, parameters);

//                // Display success message
//                lblMessage.ForeColor = System.Drawing.Color.Green;
//                lblMessage.Text = "Event created successfully!";

//                // Redirect or clear fields as necessary
//                Response.Redirect("AdminEvents.aspx");
//            }
//        }

//        //Custom Validator for Total Seats
//        protected void cvTotalSeats_ServerValidate(object source, ServerValidateEventArgs args)
//        {
//            int totalSeats;
//            if (int.TryParse(txtTotalSeats.Text, out totalSeats) && totalSeats > 0)
//            {
//                args.IsValid = true;
//            }
//            else
//            {
//                args.IsValid = false;
//            }
//        }



//    }
//}
//using System;
//using System.Web.UI.WebControls;
//using MySql.Data.MySqlClient;

//namespace EventManagementSystem
//{
//    public partial class CreateEvent : System.Web.UI.Page
//    {
//        protected void btnCreateEvent_Click(object sender, EventArgs e)
//        {
//            if (!Page.IsValid) return;

//            // Parse date exactly
//            DateTime eventDate = DateTime.ParseExact(
//                txtEventDate.Text, "yyyy-MM-dd",
//                System.Globalization.CultureInfo.InvariantCulture);

//            const string sql = @"
//                INSERT INTO Events
//                    (EventName, Description, EventDate, Venue, TotalSeats, AvailableSeats)
//                VALUES
//                    (@Name, @Desc, @Date, @Venue, @TotalSeats, @TotalSeats)";

//            var parms = new[]
//            {
//                new MySqlParameter("@Name",        txtEventName.Text.Trim()),
//                new MySqlParameter("@Desc",        txtDescription.Text.Trim()),
//                new MySqlParameter("@Date",        eventDate),
//                new MySqlParameter("@Venue",       txtVenue.Text.Trim()),
//                new MySqlParameter("@TotalSeats",  int.Parse(txtTotalSeats.Text.Trim()))
//            };

//            Database.ExecuteQuery(sql, parms);

//            Response.Redirect("AdminEvents.aspx");
//        }

//        protected void cvTotalSeats_ServerValidate(object source, ServerValidateEventArgs args)
//        {
//            args.IsValid = int.TryParse(txtTotalSeats.Text.Trim(), out var n) && n > 0;
//        }
//    }
//}
using System;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class CreateEvent : System.Web.UI.Page
    {
        // Method to convert date to a specific format
        public DateTime ConvertToDateTime(string inputDate)
        {
            DateTime result;
            // Try to parse the inputDate into a DateTime
            if (DateTime.TryParseExact(inputDate, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out result))
            {
                return result;
            }
            else
            {
                // If not in correct format, throw an exception or handle as needed
                throw new FormatException("Invalid date format. Please use yyyy-MM-dd.");
            }
        }

        protected void btnCreateEvent_Click(object sender, EventArgs e)
        {
            string eventName = txtEventName.Text;
            string description = txtDescription.Text;
            string eventDate = txtEventDate.Text;
            string venue = txtVenue.Text;
            int totalSeats = int.Parse(txtTotalSeats.Text);

            // Validate the inputs (if necessary)
            if (string.IsNullOrEmpty(eventName) || string.IsNullOrEmpty(description) ||
                string.IsNullOrEmpty(eventDate) || string.IsNullOrEmpty(venue) || totalSeats <= 0)
            {
                // Display validation message
                lblMessage.Text = "Please fill all fields correctly.";
                return;
            }

            // Insert event data into database (use your database method here)
            string query = "INSERT INTO Events (EventName, Description, EventDate, Venue, TotalSeats) VALUES (@EventName, @Description, @EventDate, @Venue, @TotalSeats)";
            MySqlParameter[] parameters = {
        new MySqlParameter("@EventName", eventName),
        new MySqlParameter("@Description", description),
        new MySqlParameter("@EventDate", DateTime.Parse(eventDate)),
        new MySqlParameter("@Venue", venue),
        new MySqlParameter("@TotalSeats", totalSeats)
    };
            Database.ExecuteQuery(query, parameters);

            // Display success message
            lblMessage.ForeColor = System.Drawing.Color.Green;
            lblMessage.Text = "Event created successfully!";

            // Redirect or clear fields as necessary
            Response.Redirect("AdminEvents.aspx");
        }

    }
}
