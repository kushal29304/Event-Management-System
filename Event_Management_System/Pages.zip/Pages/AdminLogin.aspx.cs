﻿//using System;
//using System.Data;
//using MySql.Data.MySqlClient;

//namespace EventManagementSystem
//{
//    public partial class AdminLogin : System.Web.UI.Page
//    {
//        protected void btnAdminLogin_Click(object sender, EventArgs e)
//        {
//            string username = txtAdminUsername.Text.Trim();
//            string password = txtAdminPassword.Text.Trim();

//            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
//            {
//                lblMessage.Text = "Please enter both username and password!";
//                return;
//            }

//            string query = "SELECT COUNT(*) FROM Admin WHERE Username = @Username AND Password = @Password";
//            MySqlParameter[] parameters = {
//                new MySqlParameter("@Username", username),
//                new MySqlParameter("@Password", password)
//            };

//            try
//            {
//                object result = Database.ExecuteScalar(query, parameters);

//                if (result != null && Convert.ToInt32(result) > 0)
//                {
//                    Session["Admin"] = username;
//                    Response.Redirect("AdminEvents.aspx");
//                }
//                else
//                {
//                    lblMessage.Text = "Invalid credentials!";
//                }
//            }
//            catch (Exception ex)
//            {
//                lblMessage.Text = "Error: " + ex.Message;
//            }
//        }
//    }
//}
using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void btnAdminLogin_Click(object sender, EventArgs e)
        {
            string username = txtAdminUsername.Text.Trim();
            string password = txtAdminPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                lblMessage.Text = "Please enter both username and password!";
                return;
            }

            string query = "SELECT COUNT(*) FROM Admin WHERE Username = @Username AND Password = @Password";
            MySqlParameter[] parameters = {
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password)
            };

            try
            {
                object result = Database.ExecuteScalar(query, parameters);

                if (result != null && Convert.ToInt32(result) > 0)
                {
                    Session["AdminUsername"] = username;
                    Response.Redirect("Dashboard.aspx");
                }
                else
                {
                    lblMessage.Text = "Invalid username or password!";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "An error occurred. Please try again later.";
                // Optionally log ex.Message somewhere for debugging
            }
        }
    }
}
