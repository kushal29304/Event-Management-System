﻿//using System;
//using System.Data.SqlClient;

//namespace EventManagementSystem
//{
//    public partial class Login : System.Web.UI.Page
//    {
//        protected void btnLogin_Click(object sender, EventArgs e)
//        {
//            string username = txtUsername.Text;
//            string password = txtPassword.Text;

//            if (ValidateUser(username, password))
//            {
//                // Redirect to dashboard after successful login
//                Response.Redirect("Dashboard.aspx");
//            }
//            else
//            {
//                lblMessage.Text = "Invalid login credentials. Please try again.";
//            }
//        }

//        // Method to validate the user credentials
//        private bool ValidateUser(string username, string password)
//        {
//            string query = "SELECT COUNT(*) FROM event_management.Users WHERE Username = @Username AND Password = @Password";
//            SqlParameter[] parameters = new SqlParameter[]
//            {
//                new SqlParameter("@Username", username),
//                new SqlParameter("@Password", password)
//            };

//            using (SqlDataReader reader = Database.GetDataReader(query, parameters))
//            {
//                reader.Read();
//                int count = Convert.ToInt32(reader[0]);
//                return count > 0;
//            }
//        }

//        private class Database
//        {
//            internal static SqlDataReader GetDataReader(string query, SqlParameter[] parameters)
//            {
//                throw new NotImplementedException();
//            }
//        }
//    }
//}using System;
using System;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class Login : System.Web.UI.Page
    {
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            var username = txtUsername.Text.Trim();
            var password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                lblMessage.Text = "Enter both username and password.";
                return;
            }

            if (ValidateUser(username, password))
            {
                Session["Username"] = username;
                Response.Redirect("ViewAvailableEvents.aspx", false);
            }
            else
            {
                lblMessage.Text = "Invalid credentials.";
            }
        }

        private bool ValidateUser(string username, string password)
        {
            const string query =
                "SELECT COUNT(1) " +
                "FROM Users " +
                "WHERE Username = @Username AND Password = @Password";

            var parameters = new[]
            {
                new MySqlParameter("@Username", username),
                new MySqlParameter("@Password", password)
            };

            try
            {
                var result = Database.ExecuteScalar(query, parameters);
                return (result is int count && count > 0)
                       || (result is long longCount && longCount > 0);
            }
            catch
            {
                // Log exception internally if desired
                lblMessage.Text = "An unexpected error occurred.";
                return false;
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserRegister.aspx");
        }
    }
}

