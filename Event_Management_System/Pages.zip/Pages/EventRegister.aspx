﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EventRegister.aspx.cs" Inherits="EventManagementSystem.EventRegister" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Register for Event</title>
    <style>
        body { font-family: Arial,sans-serif; background:#f4f4f9; }
        .container { width:400px; margin:60px auto; background:#fff; padding:30px;
                     border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); }
        h2 { text-align:center; color:#333; margin-bottom:20px; }
        .form-group { margin-bottom:15px; }
        .form-group label { display:block; color:#555; margin-bottom:5px; }
        .form-group input, .form-group select {
            width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;
            font-size:14px; box-sizing:border-box;
        }
        .btn { width:100%; padding:10px; background:#4CAF50; color:#fff; border:none;
               border-radius:4px; cursor:pointer; font-size:16px; }
        .btn:hover { background:#45a049; }
        #lblMessage { text-align:center; margin-top:15px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Register for Event</h2>

            <asp:Label ID="lblMessage" runat="server"></asp:Label>

            <div class="form-group">
                <label>Username<span style="color:red">*</span></label>
                <asp:TextBox ID="txtUsername" runat="server" />
            </div>

            <div class="form-group">
                <label>Select Event<span style="color:red">*</span></label>
                <asp:DropDownList ID="ddlEvents" runat="server" />
            </div>

            <asp:Button ID="btnRegister" runat="server"
                Text="Register" CssClass="btn"
                OnClick="btnRegister_Click" />
        </div>
    </form>
</body>
</html>
