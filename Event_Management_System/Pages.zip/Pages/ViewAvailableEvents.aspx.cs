﻿using System;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class ViewAvailableEvents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadAvailableEvents();
            }
        }

        //private void LoadAvailableEvents()
        //{
        //    const string query = @"
        //        SELECT EventName, EventDate, Venue, AvailableSeats
        //          FROM Events
        //         WHERE EventDate >= GETDATE()
        //           AND AvailableSeats > 0
        //         ORDER BY EventDate";

        //    using (MySqlDataReader reader = Database.GetDataReader(query))
        //    {
        //        gvAvailableEvents.DataSource = reader;
        //        gvAvailableEvents.DataBind();
        //    }
        //}

        private void LoadAvailableEvents()
        {
            const string query = @"
        SELECT EventName, EventDate, Venue, TotalSeats
          FROM Events
         WHERE EventDate >= CURDATE()
           AND TotalSeats > 0
         ORDER BY EventDate";

            using (var reader = Database.GetDataReader(query))
            {
                gvAvailableEvents.DataSource = reader;
                gvAvailableEvents.DataBind();
            }
        }

        protected void btnusereventregister_Click(object sender, EventArgs e)
        {
            // Redirect to your CreateEvent page
            Response.Redirect("EventRegister.aspx");
        }

    }
}
//using System;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using MySql.Data.MySqlClient;

//namespace EventManagementSystem
//{
//    public partial class ViewAvailableEvents : System.Web.UI.Page
//    {
//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (!IsPostBack)
//            {
//                LoadAvailableEvents();
//            }
//        }

//        // Load available events
//        private void LoadAvailableEvents()
//        {
//            string query = "SELECT EventID, EventName, EventDate, Venue, AvailableSeats FROM Events WHERE EventDate >= NOW() AND AvailableSeats > 0 ORDER BY EventDate";
//            // Assuming Database.GetDataTable() will get data and return a DataTable
//            gvAvailableEvents.DataSource = Database.GetDataReader(query);
//            gvAvailableEvents.DataBind();
//        }

//        // Handle registration button click
//        protected void gvAvailableEvents_RowCommand(object sender, GridViewCommandEventArgs e)
//        {
//            if (e.CommandName == "Register")
//            {
//                int eventId = Convert.ToInt32(e.CommandArgument);

//                // Your logic for registration, assuming a method RegisterUserForEvent
//                //bool success = RegisterUserForEvent(eventId);

//                if (success)
//                {
//                    // Optional: Show success message
//                    Response.Write("<script>alert('Registration successful!');</script>");
//                    LoadAvailableEvents(); // Refresh grid to show updated available seats
//                }
//                else
//                {
//                    // Optional: Show error message
//                    Response.Write("<script>alert('Registration failed!');</script>");
//                }
//            }
//        }

//        // Register the user for the event (add your logic here)
        
//    }
//}
