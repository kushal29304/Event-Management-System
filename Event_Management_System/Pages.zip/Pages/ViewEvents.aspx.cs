﻿using System;
using System.Data;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class ViewEvents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                LoadEvents();
        }

        private void LoadEvents()
        {
            const string query = @"
                SELECT EventID, EventName, EventDate, Venue, AvailableSeats
                  FROM Events
                 WHERE EventDate >= NOW()
                   AND AvailableSeats > 0
                 ORDER BY EventDate";

            using (var reader = Database.GetDataReader(query))
            {
                gvEvents.DataSource = reader;
                gvEvents.DataBind();
            }
        }

        protected void gvEvents_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "Register")
                return;

            // Get the index of the row
            int rowIndex = Convert.ToInt32(e.CommandArgument);

            // Ensure the DataKey is available for the given row index
            if (rowIndex >= 0 && rowIndex < gvEvents.Rows.Count)
            {
                // Access the EventID from DataKeys
                int eventId = Convert.ToInt32(gvEvents.DataKeys[rowIndex].Value);

                // TODO: Replace with real user ID from Session
                int userId = Convert.ToInt32(Session["UserID"] ?? "0");
                if (userId == 0)
                {
                    // not logged in
                    Response.Redirect("UserLogin.aspx");
                    return;
                }

                // 1) Register the user
                const string insertSql = @"
            INSERT INTO EventRegistrations (EventID, UserID, RegistrationDate)
            VALUES (@EventID, @UserID, NOW())";
                var insertParams = new[]
                {
            new MySqlParameter("@EventID", eventId),
            new MySqlParameter("@UserID",  userId)
        };
                Database.ExecuteQuery(insertSql, insertParams);

                // 2) Decrement the seat count
                const string updateSql = @"
            UPDATE Events
               SET AvailableSeats = AvailableSeats - 1
             WHERE EventID = @EventID";
                Database.ExecuteQuery(updateSql,
                    new[] { new MySqlParameter("@EventID", eventId) });
                lblMessage.Text = "Registration successful!";
                lblMessage.ForeColor = System.Drawing.Color.Green;
                // 3) Refresh
                LoadEvents();
            }
            else
            {
                // Handle invalid row index
                lblMessage.Text = "Invalid event selection.";
            }
        }

    }
}
