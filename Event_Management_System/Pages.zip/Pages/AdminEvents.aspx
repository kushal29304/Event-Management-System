﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AdminEvents.aspx.cs" Inherits="EventManagementSystem.AdminEvents" %>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Events (Admin)</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="margin:20px;">
            <h2>Manage Events</h2>

            <asp:GridView ID="gvEvents" runat="server" AutoGenerateColumns="False" DataKeyNames="EventID" OnRowEditing="gvEvents_RowEditing" OnRowCancelingEdit="gvEvents_RowCancelingEdit" OnRowUpdating="gvEvents_RowUpdating" OnRowDeleting="gvEvents_RowDeleting">
                <Columns>
                    <asp:BoundField DataField="EventID" HeaderText="ID" ReadOnly="True" />
                    <asp:BoundField DataField="EventName" HeaderText="Event Name" />
                    <asp:BoundField DataField="EventDate" HeaderText="Event Date" DataFormatString="{0:yyyy-MM-dd}" />
                    <asp:BoundField DataField="Venue" HeaderText="Venue" />
                    <asp:BoundField DataField="AvailableSeats" HeaderText="Seats" />
                    <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" />
                </Columns>
            </asp:GridView>

            <br />
            <h3>Add New Event</h3>
            Event Name: <asp:TextBox ID="txtEventName" runat="server" /><br /><br />
            Event Date: <asp:TextBox ID="txtEventDate" runat="server" Placeholder="yyyy-MM-dd" /><br /><br />
            Venue: <asp:TextBox ID="txtVenue" runat="server" /><br /><br />
            Available Seats: <asp:TextBox ID="txtSeats" runat="server" /><br /><br />

            <asp:Button ID="btnAddEvent" runat="server" Text="Add Event" OnClick="btnAddEvent_Click" />
            <asp:Label ID="lblMessage" runat="server" ForeColor="Green"></asp:Label>

        </div>
    </form>
</body>
</html>--%>

<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="AdminEvents.aspx.cs"
    Inherits="EventManagementSystem.AdminEvents" %>

<!DOCTYPE html>
<html>
<head runat="server">
    <title>Manage Events (Admin)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        h2, h3 {
            color: #333;
            margin-bottom: 20px;
        }

        .grid-wrapper {
            margin-bottom: 40px;
        }

        .grid {
            width: 100%;
            border-collapse: collapse;
        }

            .grid th, .grid td {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: left;
            }

            .grid th {
                background-color: #4CAF50;
                color: white;
            }

            .grid tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .grid tr:hover {
                background-color: #f1f1f1;
            }

        .form-group {
            display: flex;
            margin-bottom: 15px;
            align-items: center;
        }

            .form-group label {
                width: 150px;
                font-weight: bold;
                color: #555;
            }

            .form-group input {
                flex: 1;
                padding: 8px 10px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 14px;
            }

        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 15px;
            margin-top: 10px;
        }

            .btn:hover {
                background-color: #45a049;
            }

        #lblMessage {
            display: block;
            margin-top: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Manage Events</h2>

            <!-- Grid of existing events -->
            <div class="grid-wrapper">
                <asp:GridView ID="gvEvents" runat="server"
                    AutoGenerateColumns="False"
                    DataKeyNames="EventID"
                    CssClass="grid"
                    OnRowEditing="gvEvents_RowEditing"
                    OnRowCancelingEdit="gvEvents_RowCancelingEdit"
                    OnRowUpdating="gvEvents_RowUpdating"
                    OnRowDeleting="gvEvents_RowDeleting">
                    <Columns>
                        <asp:BoundField DataField="EventID" HeaderText="ID" ReadOnly="True" />
                        <asp:BoundField DataField="EventName" HeaderText="Event Name" />
                        <asp:BoundField DataField="EventDate" HeaderText="Event Date"
                            DataFormatString="{0:yyyy-MM-dd}" />
                        <asp:BoundField DataField="Venue" HeaderText="Venue" />
                        <asp:BoundField DataField="TotalSeats" HeaderText="TotalSeats" />
                        <asp:CommandField ShowEditButton="True" ShowDeleteButton="True" />
                    </Columns>
                </asp:GridView>
            </div>

           
           <asp:Button ID="btnAddNewEvent"
            runat="server"
            Text="Add New Event"
            OnClick="btnAddNewEvent_Click"
            CssClass="btn" />
            <asp:Label ID="lblMessage" runat="server" ForeColor="Green"></asp:Label>
        </div>
    </form>
</body>
</html>

