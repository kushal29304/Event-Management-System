﻿//using System;
//using System.Data.SqlClient;

//namespace EventManagementSystem
//{
//    public partial class Dashboard : System.Web.UI.Page
//    {
//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (!IsPostBack)
//            {
//                LoadEvents();
//                LoadUsers();
//            }
//        }

//        // Load events into GridView
//        private void LoadEvents()
//        {
//            string query = "SELECT * FROM event_management.Events";
//            using (SqlDataReader reader = Database.GetDataReader(query, null))
//            {
//                gvEvents.DataSource = reader;
//                gvEvents.DataBind();
//            }
//        }

//        // Load users into GridView
//        private void LoadUsers()
//        {
//            string query = "SELECT * FROM event_management.Users";
//            using (SqlDataReader reader = Database.GetDataReader(query, null))
//            {
//                gvUsers.DataSource = reader;
//                gvUsers.DataBind();
//            }
//        }

//        private class Database
//        {


//            internal static SqlDataReader GetDataReader(string query, object value)
//            {
//                throw new NotImplementedException();
//            }
//        }
//    }
//}
using System;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadEvents();
                LoadUsers();
            }
        }

        // Bind all events into gvEvents
        private void LoadEvents()
        {
            const string query = "SELECT * FROM Events";
            using (MySqlDataReader reader = Database.GetDataReader(query))
            {
                gvEvents.DataSource = reader;
                gvEvents.DataBind();
            }
        }

        // Bind all users into gvUsers
        private void LoadUsers()
        {
            const string query = "SELECT * FROM Users";
            using (MySqlDataReader reader = Database.GetDataReader(query))
            {
                gvUsers.DataSource = reader;
                gvUsers.DataBind();
            }
        }

        protected void btnAddEvent_Click(object sender, EventArgs e)
        {
            // Redirect to the Add Event page or display a modal for adding a new event
            Response.Redirect("CreateEvent.aspx");
        }

        protected void btnManageEvent_Click(object sender, EventArgs e)
        {
            // Redirect to the Manage Users page or display a modal for user management
            Response.Redirect("AdminEvents.aspx");
        }

        //protected void btnManageEvent_Click(object sender, EventArgs e)
        //{
        //    // Redirect to the Add Event page or display a modal for adding a new event
        //    Response.Redirect("AdminEvent.aspx");
        //}
    }
}
