﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ViewAvailableEvents.aspx.cs" Inherits="EventManagementSystem.ViewAvailableEvents" %>

<!DOCTYPE html>
<html>
<head>
    <title>Available Events</title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <h2>Upcoming Events</h2>

            <asp:GridView ID="gvAvailableEvents" runat="server" AutoGenerateColumns="False">
                <Columns>
                    <asp:BoundField DataField="EventName" HeaderText="Event Name" />
                    <asp:BoundField DataField="EventDate" HeaderText="Event Date" DataFormatString="{0:dd/MM/yyyy}" />
                    <asp:BoundField DataField="Venue" HeaderText="Venue" />
                    <asp:BoundField DataField="AvailableSeats" HeaderText="Available Seats" />
                </Columns>
            </asp:GridView>
        </div>
    </form>
</body>
</html>--%>

<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ViewAvailableEvents.aspx.cs" Inherits="EventManagementSystem.ViewAvailableEvents" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Events</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
            margin-bottom: 20px;
        }

        .grid-wrapper {
            margin-bottom: 40px;
        }

        .grid {
            width: 100%;
            border-collapse: collapse;
        }

            .grid th, .grid td {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: left;
            }

            .grid th {
                background-color: #4CAF50;
                color: white;
            }

            .grid tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            .grid tr:hover {
                background-color: #f1f1f1;
            }

        .btn {
            padding: 8px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }

            .btn:hover {
                background-color: #45a049;
            }

        .register-btn {
            text-align: center;
            padding: 10px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Upcoming Events</h2>

            <asp:GridView ID="gvAvailableEvents" runat="server" AutoGenerateColumns="False">
                <Columns>
                    <asp:BoundField DataField="EventName" HeaderText="Event Name" />
                    <asp:BoundField DataField="EventDate" HeaderText="Event Date" DataFormatString="{0:dd/MM/yyyy}" />
                    <asp:BoundField DataField="Venue" HeaderText="Venue" />
                    <asp:BoundField DataField="TotalSeats" HeaderText="Total Seats" />
                </Columns>
            </asp:GridView>

            <asp:Button ID="btnusereventregister"
                runat="server"
                Text="Register Event"
                OnClick="btnusereventregister_Click"
                CssClass="btn" />
        </div>
    </form>
</body>
</html>
