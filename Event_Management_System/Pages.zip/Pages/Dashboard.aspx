﻿<%--<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="EventManagementSystem.Dashboard" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <h2>Welcome, Admin</h2>
            <h3>Event List:</h3>
            <asp:GridView ID="gvEvents" runat="server" AutoGenerateColumns="True"></asp:GridView>
            <h3>Users List:</h3>
            <asp:GridView ID="gvUsers" runat="server" AutoGenerateColumns="True"></asp:GridView>
        </div>
    </form>
</body>
</html>--%>

<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="EventManagementSystem.Dashboard" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        h3 {
            color: #555;
            margin-bottom: 15px;
        }

        .grid-container {
            margin-top: 30px;
        }

            .grid-container .grid {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 30px;
            }

                .grid-container .grid th, .grid-container .grid td {
                    padding: 12px 15px;
                    border: 1px solid #ddd;
                    text-align: left;
                }

                .grid-container .grid th {
                    background-color: #4CAF50;
                    color: white;
                }

                .grid-container .grid tr:hover {
                    background-color: #f1f1f1;
                }

        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .btn {
            padding: 12px 25px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            margin: 10px;
            border-radius: 5px;
        }

            .btn:hover {
                background-color: #45a049;
            }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Welcome, Admin</h2>

            <div class="button-container">
                <asp:Button ID="btnAddEvent" runat="server" Text="Add New Event" OnClick="btnAddEvent_Click" CssClass="btn" />
                <asp:Button ID="btnManageEvents" runat="server" Text="Manage Events" OnClick="btnManageEvent_Click" CssClass="btn" />
            </div>

            <h3>Event List:</h3>
            <div class="grid-container">
                <asp:GridView ID="gvEvents" runat="server" AutoGenerateColumns="True" CssClass="grid"></asp:GridView>
            </div>

            <h3>Users List:</h3>
            <div class="grid-container">
                <asp:GridView ID="gvUsers" runat="server" AutoGenerateColumns="True" CssClass="grid"></asp:GridView>
            </div>
        </div>
    </form>
</body>
</html>

