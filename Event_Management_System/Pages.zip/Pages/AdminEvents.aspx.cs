﻿//using System;
//using System.Data;
//using System.Data.SqlClient;

//namespace EventManagementSystem
//{
//    public partial class AdminEvents : System.Web.UI.Page
//    {
//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (!IsPostBack)
//            {
//                LoadEvents();
//            }
//        }

//        private void LoadEvents()
//        {
//            string query = "SELECT * FROM Events ORDER BY EventDate";

//            using (SqlDataReader reader = Database.GetDataReader(query))
//            {
//                DataTable dt = new DataTable();
//                dt.Load(reader);
//                gvEvents.DataSource = dt;
//                gvEvents.DataBind();
//            }
//        }

//        protected void btnAddEvent_Click(object sender, EventArgs e)
//        {
//            string name = txtEventName.Text.Trim();
//            DateTime date = Convert.ToDateTime(txtEventDate.Text.Trim());
//            string venue = txtVenue.Text.Trim();
//            int seats = int.Parse(txtSeats.Text.Trim());

//            string query = "INSERT INTO Events (EventName, EventDate, Venue, AvailableSeats) VALUES (@Name, @Date, @Venue, @Seats)";
//            SqlParameter[] parameters = {
//                new SqlParameter("@Name", name),
//                new SqlParameter("@Date", date),
//                new SqlParameter("@Venue", venue),
//                new SqlParameter("@Seats", seats)
//            };

//            Database.ExecuteQuery(query, parameters);
//            lblMessage.Text = "Event added successfully!";
//            LoadEvents();
//        }

//        protected void gvEvents_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
//        {
//            gvEvents.EditIndex = e.NewEditIndex;
//            LoadEvents();
//        }

//        protected void gvEvents_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
//        {
//            gvEvents.EditIndex = -1;
//            LoadEvents();
//        }

//        protected void gvEvents_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
//        {
//            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);
//            string name = ((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
//            DateTime date = Convert.ToDateTime(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
//            string venue = ((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
//            int seats = int.Parse(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[4].Controls[0]).Text);

//            string query = "UPDATE Events SET EventName=@Name, EventDate=@Date, Venue=@Venue, AvailableSeats=@Seats WHERE EventID=@EventID";
//            SqlParameter[] parameters = {
//                new SqlParameter("@Name", name),
//                new SqlParameter("@Date", date),
//                new SqlParameter("@Venue", venue),
//                new SqlParameter("@Seats", seats),
//                new SqlParameter("@EventID", eventId)
//            };

//            Database.ExecuteQuery(query, parameters);

//            gvEvents.EditIndex = -1;
//            LoadEvents();
//        }

//        protected void gvEvents_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
//        {
//            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);

//            string query = "DELETE FROM Events WHERE EventID=@EventID";
//            SqlParameter[] parameters = {
//                new SqlParameter("@EventID", eventId)
//            };

//            Database.ExecuteQuery(query, parameters);
//            LoadEvents();
//        }
//    }
//}
using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class AdminEvents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadEvents();
            }
        }

        private void LoadEvents()
        {
            string query = "SELECT * FROM Events ORDER BY EventDate";

            using (MySqlDataReader reader = Database.GetDataReader(query))
            {
                DataTable dt = new DataTable();
                dt.Load(reader);
                gvEvents.DataSource = dt;
                gvEvents.DataBind();
            }
        }



        protected void gvEvents_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            gvEvents.EditIndex = e.NewEditIndex;
            LoadEvents();
        }

        protected void gvEvents_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            gvEvents.EditIndex = -1;
            LoadEvents();
        }

        protected void gvEvents_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);
            string name = ((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[1].Controls[0]).Text;
            DateTime date = Convert.ToDateTime(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
            string venue = ((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[3].Controls[0]).Text;
            int TotalSeats = int.Parse(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[4].Controls[0]).Text);

            string query = "UPDATE Events SET EventName=@Name, EventDate=@Date, Venue=@Venue, TotalSeats=@TotalSeats WHERE EventID=@EventID";
            MySqlParameter[] parameters = {
                new MySqlParameter("@Name", name),
                new MySqlParameter("@Date", date),
                new MySqlParameter("@Venue", venue),
                new MySqlParameter("@TotalSeats", TotalSeats),
                new MySqlParameter("@EventID", eventId)
            };

            Database.ExecuteQuery(query, parameters);

            gvEvents.EditIndex = -1;
            LoadEvents();
        }

        protected void gvEvents_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {
            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);

            string query = "DELETE FROM Events WHERE EventID=@EventID";
            MySqlParameter[] parameters = {
                new MySqlParameter("@EventID", eventId)
            };

            Database.ExecuteQuery(query, parameters);
            LoadEvents();
        }
        protected void btnAddNewEvent_Click(object sender, EventArgs e)
        {
            // Redirect to your CreateEvent page
            Response.Redirect("CreateEvent.aspx");
        }
    }
}
//using System;
//using System.Data;
//using System.Globalization;
//using System.Web.UI.WebControls;
//using MySql.Data.MySqlClient;

//namespace EventManagementSystem
//{
//    public partial class AdminEvents : System.Web.UI.Page
//    {
//        protected void Page_Load(object sender, EventArgs e)
//        {
//            if (!IsPostBack)
//                LoadEvents();
//        }

//        private void LoadEvents()
//        {
//            const string query = @"
//                SELECT EventID, EventName, EventDate, Venue, TotalSeats
//                  FROM Events
//                 ORDER BY EventDate";

//            using (var reader = Database.GetDataReader(query))
//            {
//                var dt = new DataTable();
//                dt.Load(reader);
//                gvEvents.DataSource = dt;
//                gvEvents.DataBind();
//            }
//        }

//        protected void btnAddNewEvent_Click(object sender, EventArgs e)
//        {
//            Response.Redirect("CreateEvent.aspx");
//        }

//        protected void gvEvents_RowEditing(object sender, GridViewEditEventArgs e)
//        {
//            gvEvents.EditIndex = e.NewEditIndex;
//            LoadEvents();
//        }

//        protected void gvEvents_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
//        {
//            gvEvents.EditIndex = -1;
//            LoadEvents();
//        }

//        //protected void gvEvents_RowUpdating(object sender, GridViewUpdateEventArgs e)
//        //{
//        //    int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);
//        //    GridViewRow row = gvEvents.Rows[e.RowIndex];

//        //    string name = ((TextBox)row.Cells[1].Controls[0]).Text.Trim();
//        //    DateTime date = Convert.ToDateTime(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[2].Controls[0]).Text);
//        //    string venue = ((TextBox)row.Cells[3].Controls[0]).Text.Trim();
//        //    int totalSeats = Convert.ToInt32(row.Cells[4].Text);
//        //    //int availableSeats = Convert.ToInt32(
//        //    //    ((TextBox)row.Cells[5].Controls[0]).Text.Trim());

//        //    const string updateSql = @"
//        //        UPDATE Events
//        //           SET EventName      = @Name,
//        //               EventDate      = @Date,
//        //               Venue          = @Venue,
//        //               TotalSeats     = @TotalSeats,
//        //               //AvailableSeats = @AvailableSeats
//        //         WHERE EventID = @EventID";

//        //    var parameters = new[]
//        //    {
//        //        new MySqlParameter("@Name", name),
//        //        new MySqlParameter("@Date", date),
//        //        new MySqlParameter("@Venue", venue),
//        //        new MySqlParameter("@TotalSeats", totalSeats),
//        //        //new MySqlParameter("@AvailableSeats", availableSeats),
//        //        new MySqlParameter("@EventID", eventId)
//        //    };

//        //    Database.ExecuteQuery(updateSql, parameters);

//        //    gvEvents.EditIndex = -1;
//        //    LoadEvents();
//        //}

//        protected void gvEvents_RowUpdating(object sender, GridViewUpdateEventArgs e)
//        {
//            // 1) Get the EventID
//            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);
//            GridViewRow row = gvEvents.Rows[e.RowIndex];

//            // 2) Read the edited values from the TextBoxes in the row:

//            string name = ((TextBox)row.Cells[1].Controls[0]).Text.Trim();

//            // If your EventDate column is a BoundField, it'll render a TextBox in edit mode:
//            DateTime date = Convert.ToDateTime(((System.Web.UI.WebControls.TextBox)gvEvents.Rows[e.RowIndex].Cells[2].Controls[0]).Text);

//            string venue = ((TextBox)row.Cells[3].Controls[0]).Text.Trim();

//            // TotalSeats is now editable too:
//            int totalSeats = int.Parse(
//                ((TextBox)row.Cells[4].Controls[0]).Text.Trim());

//            // And AvailableSeats (column index 5):
//            //int availableSeats = int.Parse(
//            //    ((TextBox)row.Cells[5].Controls[0]).Text.Trim());

//            // 3) Correct SQL string (no C# comments inside!)
//            const string updateSql = @"
//                UPDATE Events
//                   SET EventName      = @Name,
//                       EventDate      = @Date,
//                       Venue          = @Venue,
//                       TotalSeats     = @TotalSeats,
//                 WHERE EventID = @EventID";

//            var parameters = new[]
//            {
//                new MySqlParameter("@Name",           name),
//                new MySqlParameter("@Date",           date),
//                new MySqlParameter("@Venue",          venue),
//                new MySqlParameter("@TotalSeats",     totalSeats),
//                //new MySqlParameter("@AvailableSeats", availableSeats),
//                new MySqlParameter("@EventID",        eventId)
//            };

//            // 4) Execute and rebind
//            Database.ExecuteQuery(updateSql, parameters);
//            gvEvents.EditIndex = -1;
//            LoadEvents();
//        }


//        protected void gvEvents_RowDeleting(object sender, GridViewDeleteEventArgs e)
//        {
//            int eventId = Convert.ToInt32(gvEvents.DataKeys[e.RowIndex].Value);
//            const string deleteSql = "DELETE FROM Events WHERE EventID = @EventID";
//            var param = new MySqlParameter("@EventID", eventId);

//            Database.ExecuteQuery(deleteSql, new[] { param });
//            LoadEvents();
//        }
//    }
//}
