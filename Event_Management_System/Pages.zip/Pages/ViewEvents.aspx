﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ViewEvents.aspx.cs" Inherits="EventManagementSystem.ViewEvents" %>

<!DOCTYPE html>
<html>
<head>
    <title>Available Events</title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <h2>Available Events</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Red" />
            <asp:GridView ID="gvEvents" runat="server" AutoGenerateColumns="False" OnRowCommand="gvEvents_RowCommand" DataKeyNames="EventID">
                <Columns>
                    <asp:BoundField DataField="EventName" HeaderText="Event Name" />
                    <asp:BoundField DataField="EventDate" HeaderText="Date" />
                    <asp:BoundField DataField="Venue" HeaderText="Venue" />
                    <asp:BoundField DataField="AvailableSeats" HeaderText="Seats Left" />
                    <asp:ButtonField ButtonType="Button" CommandName="Register" Text="Register" />
                </Columns>
            </asp:GridView>
        </div>
    </form>
</body>
</html>
