﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="CreateEvent.aspx.cs" Inherits="EventManagementSystem.CreateEvent" %>

<!DOCTYPE html>
<html>
<head>
    <title>Create Event</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 60%;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .form-group textarea {
            resize: vertical;
        }

        .form-group input[type="date"] {
            padding: 11px;
        }

        .form-group input[type="number"] {
            padding: 11px;
        }

        .form-group input:focus, .form-group textarea:focus {
            border-color: #4CAF50;
            outline: none;
        }

        .btn-container {
            text-align: center;
        }

        .btn {
            padding: 12px 30px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="container">
            <h2>Create New Event</h2>

            <!-- Label to display messages (success or error) -->
            <asp:Label ID="lblMessage" runat="server" CssClass="error-message"></asp:Label><br />

            <div class="form-group">
                <label for="txtEventName">Event Name:</label>
                <asp:TextBox ID="txtEventName" runat="server" CssClass="form-control" />
            </div>

            <div class="form-group">
                <label for="txtDescription">Description:</label>
                <asp:TextBox ID="txtDescription" runat="server" TextMode="MultiLine" CssClass="form-control" Rows="4" />
            </div>

            <div class="form-group">
                <label for="txtEventDate">Event Date:</label>
                <asp:TextBox ID="txtEventDate" runat="server" Placeholder="yyyy-MM-dd" CssClass="form-control" />
            </div>

            <div class="form-group">
                <label for="txtVenue">Venue:</label>
                <asp:TextBox ID="txtVenue" runat="server" CssClass="form-control" />
            </div>

            <div class="form-group">
                <label for="txtTotalSeats">Total Seats:</label>
                <asp:TextBox ID="txtTotalSeats" runat="server" CssClass="form-control" />
            </div>

            <div class="btn-container">
                <asp:Button ID="btnCreateEvent" runat="server" Text="Create Event" OnClick="btnCreateEvent_Click" CssClass="btn" />
            </div>
        </div>
    </form>
</body>
</html>
