﻿using System;

namespace EventManagementSystem
{
    public partial class Home : System.Web.UI.Page
    {
        protected void btnViewEvents_Click(object sender, EventArgs e)
        {
            Response.Redirect("ViewAvailableEvents.aspx");
        }

        protected void btnRegisterEvent_Click(object sender, EventArgs e)
        {
            Response.Redirect("EventRegister.aspx");
        }

        protected void btnMyRegistrations_Click(object sender, EventArgs e)
        {
            Response.Redirect("MyRegistrations.aspx");
        }
        protected void btnUserLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void btnAdminLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        protected void btnUserRegister_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserRegister.aspx");
        }
        //protected void btnViewEvents_Click(object sender, EventArgs e)
        //{
        //    // Redirect to the events listing page
        //    Response.Redirect("ViewEvents.aspx");
        //}

        //protected void btnUserLogin_Click(object sender, EventArgs e)
        //{
        //    // Redirect to the user login page
        //    Response.Redirect("Login.aspx");
        //}

        //protected void btnAdminLogin_Click(object sender, EventArgs e)
        //{
        //    // Redirect to the admin login page
        //    Response.Redirect("AdminLogin.aspx");
        //}

    }
}
