﻿using System;
using System.Data;
using System.Drawing;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace EventManagementSystem
{
    public partial class EventRegister : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) LoadEvents();
        }

        private void LoadEvents()
        {
            const string sql = @"
                SELECT EventID, EventName
                  FROM Events
                 WHERE EventDate >= NOW()
                   AND TotalSeats > 0
                 ORDER BY EventDate";
            using (var rdr = Database.GetDataReader(sql))
            {
                var dt = new DataTable(); dt.Load(rdr);
                ddlEvents.DataSource = dt;
                ddlEvents.DataTextField = "EventName";
                ddlEvents.DataValueField = "EventID";
                ddlEvents.DataBind();
            }
            ddlEvents.Items.Insert(0, new ListItem("-- Select --", "0"));
        }

        protected void btnRegister_Click(object s, EventArgs e)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "";

            var username = txtUsername.Text.Trim();
            if (string.IsNullOrWhiteSpace(username))
            {
                lblMessage.Text = "Enter username."; return;
            }

            if (!int.TryParse(ddlEvents.SelectedValue, out int evId) || evId == 0)
            {
                lblMessage.Text = "Select an event."; return;
            }

            // Lookup UserID
            const string uSql = "SELECT UserID FROM Users WHERE Username=@u";
            int userId;
            using (var r = Database.GetDataReader(uSql,
                       new[] { new MySqlParameter("@u", username) }))
            {
                if (!r.Read())
                {
                    lblMessage.Text = "User not found!"; return;
                }
                userId = r.GetInt32("UserID");
            }

            // Already registered?
            const string cSql = @"
                SELECT COUNT(1)
                  FROM EventRegistrations
                 WHERE EventID=@e AND UserID=@u";
            var count = Convert.ToInt32(
                Database.ExecuteScalar(cSql,
                    new[] {
                      new MySqlParameter("@e", evId),
                      new MySqlParameter("@u", userId)
                    }));
            if (count > 0)
            {
                lblMessage.Text = "Already registered."; return;
            }

            // Register + decrement seat
            const string iSql = @"
                INSERT INTO EventRegistrations
                    (EventID, UserID, RegistrationDate)
                VALUES
                    (@e, @u, NOW())";
            Database.ExecuteQuery(iSql,
                new[] {
                    new MySqlParameter("@e", evId),
                    new MySqlParameter("@u", userId)
                });

            const string upd = @"
                UPDATE Events
                   SET TotalSeats = TotalSeats - 1
                 WHERE EventID = @e";
            Database.ExecuteQuery(upd,
                new[] { new MySqlParameter("@e", evId) });

            lblMessage.ForeColor = Color.Green;
            lblMessage.Text = "Registered!";
            LoadEvents();

            Response.Redirect("MyRegistrations.aspx");

        }
    }
}
